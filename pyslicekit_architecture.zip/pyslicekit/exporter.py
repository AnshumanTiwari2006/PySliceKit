"""
pyslicekit.exporter
~~~~~~~~~~~~~~~~~~~
Export SliceResult lists to CSV or JSON.

Usage:
    from pyslicekit.exporter import to_csv, to_json
"""

import csv
import json
from typing import List

from pyslicekit.types import SliceResult


def to_csv(results: List[SliceResult], filepath: str) -> None:
    """
    Export the evaluation results to a CSV file.

    Parameters
    ----------
    results : List[SliceResult]
        The list of results returned by evaluate().
    filepath : str
        The destination file path.
    """
    if not results:
        return

    # Extract field names
    fieldnames = [
        "segment", "n", "metric", "metric_value", "overall_metric",
        "gap", "is_significant", "low_n", "p_value", "test_used"
    ]

    with open(filepath, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            writer.writerow({
                "segment": r.label,
                "n": r.n,
                "metric": r.metric_name,
                "metric_value": r.metric_value,
                "overall_metric": r.overall_metric,
                "gap": r.gap,
                "is_significant": r.is_significant,
                "low_n": r.low_n,
                "p_value": r.p_value,
                "test_used": r.test_used or "",
            })


def to_json(results: List[SliceResult], filepath: str) -> None:
    """
    Export the evaluation results to a JSON file.

    Parameters
    ----------
    results : List[SliceResult]
        The list of results returned by evaluate().
    filepath : str
        The destination file path.
    """
    if not results:
        with open(filepath, mode="w", encoding="utf-8") as f:
            json.dump([], f)
        return

    data = []
    for r in results:
        data.append({
            "segment": r.label,
            "slice_def": r.slice_def,
            "n": r.n,
            "metric": r.metric_name,
            "metric_value": r.metric_value,
            "overall_metric": r.overall_metric,
            "gap": r.gap,
            "is_significant": r.is_significant,
            "low_n": r.low_n,
            "p_value": r.p_value,
            "test_used": r.test_used,
        })

    with open(filepath, mode="w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
