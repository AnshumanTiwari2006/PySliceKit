"""
pyslicekit.api
~~~~~~~~~~~~~~
Public entry point for the library.

Usage:
    from pyslicekit import evaluate
    results = evaluate(model, df, y_true, y_pred, slice_cols=["region", "age"])
"""

from __future__ import annotations

from typing import Any, List, Optional

import pandas as pd

from pyslicekit.exceptions import PySliceKitNoSegmentsError
from pyslicekit.renderer import render
from pyslicekit.slicer import build_segments
from pyslicekit.stats import compute_overall_metric, detect_task_type, evaluate_segment
from pyslicekit.types import SliceResult
from pyslicekit.validators import validate_inputs


def evaluate(
    model: Any,
    df: pd.DataFrame,
    y_true: Any,
    y_pred: Any,
    slice_cols: List[str],
    metric: str = "accuracy",
    min_samples: int = 30,
    depth: int = 2,
    render_visuals: bool = True,
    **render_kwargs: Any,
) -> List[SliceResult]:
    """
    Evaluate a model across data slices to find underperforming segments.

    Parameters
    ----------
    model : Any
        An sklearn-compatible model (must have a predict method).
    df : pd.DataFrame
        The feature dataset.
    y_true : array-like
        Ground truth labels or values.
    y_pred : array-like
        Model predictions.
    slice_cols : List[str]
        List of column names in `df` to slice on.
    metric : str, optional
        The evaluation metric (e.g., "accuracy", "f1", "mae"). Default is "accuracy".
    min_samples : int, optional
        Minimum number of samples required to consider a segment reliable. Default is 30.
    depth : int, optional
        Maximum combination depth for slices (1 or 2). Default is 2.
    render_visuals : bool, optional
        Whether to render the heatmap and bar chart automatically. Default is True.
    **render_kwargs : Any
        Additional arguments passed to the renderer (e.g., `top_n`, `show`, `save_path`).

    Returns
    -------
    List[SliceResult]
        A list of evaluated segments, sorted by absolute gap descending.
    """
    # 1. Validate inputs
    validate_inputs(
        model=model,
        df=df,
        y_true=y_true,
        y_pred=y_pred,
        slice_cols=slice_cols,
        metric=metric,
        min_samples=min_samples,
        depth=depth,
    )

    # 2. Detect task type
    is_regression = detect_task_type(y_true, metric)

    # 3. Compute overall baseline
    overall_metric = compute_overall_metric(y_true, y_pred, metric)

    # 4. Build segments
    segment_dicts = build_segments(
        df=df,
        y_true=y_true,
        y_pred=y_pred,
        slice_cols=slice_cols,
        depth=depth,
        min_samples=min_samples,
    )

    # 5. Evaluate segments
    results = []
    for seg in segment_dicts:
        result = evaluate_segment(
            segment=seg,
            metric=metric,
            overall_metric=overall_metric,
            is_regression=is_regression,
            min_samples=min_samples,
        )
        results.append(result)

    # Filter out empty segments (where n=0, though slicer drops them)
    results = [r for r in results if r.n > 0]

    if not results or all(r.low_n for r in results):
        raise PySliceKitNoSegmentsError(
            "All candidate segments were dropped or had n < min_samples. "
            "Try choosing different slice columns or lowering min_samples."
        )

    # 6. Sort results by absolute gap descending (worst first)
    results.sort(key=lambda r: r.abs_gap, reverse=True)

    # 7. Render visuals
    if render_visuals:
        render(results, **render_kwargs)

    return results
