"""
pyslicekit.exceptions
~~~~~~~~~~~~~~~~~~~~~
Typed error classes for pyslicekit.

Every error raised by the library is a subclass of PySliceKitError,
so users can catch all library errors with a single except clause
while still being able to distinguish specific failure modes.

Usage:
    from pyslicekit.exceptions import (
        PySliceKitError,
        PySliceKitValidationError,
        PySliceKitNoSegmentsError,
        PySliceKitMetricError,
        PySliceKitRenderError,
    )
"""


class PySliceKitError(Exception):
    """
    Base class for all pyslicekit errors.

    Catch this to handle any library error generically:

        try:
            results = pyslicekit.evaluate(...)
        except PySliceKitError as e:
            print(f"pyslicekit failed: {e}")
    """


class PySliceKitValidationError(PySliceKitError):
    """
    Raised when the inputs to evaluate() fail validation.

    Common causes:
    - y_true and y_pred have different lengths
    - slice_cols contains column names not present in df
    - metric name is not in SUPPORTED_METRICS
    - model has no predict() method
    - df is empty

    The error message always names the specific problem:
        PySliceKitValidationError(
            "y_true has 100 rows but y_pred has 99 rows"
        )
    """


class PySliceKitNoSegmentsError(PySliceKitError):
    """
    Raised when slicing produces zero usable segments.

    This happens when every candidate segment has n < min_samples
    and there is nothing left to evaluate.

    Includes a suggestion to lower min_samples or change slice_cols:
        PySliceKitNoSegmentsError(
            "All 12 segments had n < 30. "
            "Try min_samples=10 or choose fewer slice columns."
        )
    """


class PySliceKitMetricError(PySliceKitError):
    """
    Raised when metric computation fails for a structural reason.

    This is distinct from a NaN result (which is handled gracefully
    inside SliceResult). This error fires when the metric function
    itself raises — e.g. when y_pred contains values outside [0, 1]
    for a metric that requires probabilities.

    Includes the segment label and original exception in the message.
    """


class PySliceKitRenderError(PySliceKitError):
    """
    Raised when the renderer fails to produce a figure.

    Common cause: matplotlib backend not available in the environment
    (e.g. headless server with no display). The message includes
    a suggestion to use save_path= instead of show=True.
    """
